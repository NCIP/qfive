### Name: q5
### Title: Q5 Discriminant Analysis
### Aliases: q5 Q5
### Keywords: programming

### ** Examples

## Not run: 
##D caseData <- mzXML('cancer.mzXML')
##D controlData <- mzXML('control.mzXML')
##D 
##D percentForTraining <- .5
##D 
##D indices <- 1:nrow(controlData$peaks)
##D # ixTraCon means training indices of control matrix.
##D ixTraCon <- sample(indices, floor(percentForTraining * length(indices)))
##D # ixTesCon means testing indices of control matrix.
##D ixTesCon <- indices[-1 * ixTraCon]
##D 
##D indices <- 1:nrow(caseData$peaks)
##D # ixTraCase means training indices of case matrix.
##D ixTraCase <- sample(indices, floor(percentForTraining * length(indices)))
##D # ixTesCase means testing indices of case matrix.
##D ixTesCase <- indices[-1 * ixTraCase]
##D 
##D trainData <- rbind(controlData$peaks[ixTraCon,], caseData$peaks[ixTraCase,])
##D trainClasses <- c(rep(0, length(ixTraCon)), rep(1, length(ixTraCase)))
##D 
##D testData <- rbind(controlData$peaks[ixTesCon,], caseData$peaks[ixTesCase,])
##D testClasses <- c(rep(0, length(ixTesCon)), rep(1, length(ixTesCase)))
##D 
##D statfile <- NULL
##D plotfile <- NULL
##D q5Res <- q5(trainData, trainClasses, testData, testClasses, pca, lda, pcaProject, MASS:::predict.ld, statfile, plotfile)
## End(Not run)



