library(MASS)
library(caMassClass)

mzXML <- function(filename) {
  data <- NULL
  mz <- read.mzXML(filename)
  for (scan in mz$scan) {
    data$peaks <- rbind(data$peaks, scan$peaks)
    data$mass <- rbind(data$mass, scan$mass)
  }
  return(data)
}

normalize <- function(mat) {
  for (ixRow in seq(nrow(mat))) {
    rowMin <- min(mat[ixRow,])
    rowRange <- max(mat[ixRow,]) - rowMin
    mat[ixRow,] <- (mat[ixRow,] - rowMin) / rowRange
  }
  return(mat)
}

pca <- function(mat) {
  z <- svd(mat)
  d <- diag(z$d)
  pcs <- z$u %*% d
  return(list(mat=pcs, eigvecs=z$v, eigvals=d))
}

pcaProject <- function(mat, eigvecs){
  # project into the pca space
  mat <- mat %*% eigvecs
  return(mat)
}

q5 <- function(trainData, trainClasses, testData, testClasses,
               reductionFunction=pca, discriminantFunction=lda,
               projectionFunction=pcaProject,
               predictionFunction=MASS:::predict.lda){
  # for trainClasses and testClasses, 1 indicates disease.
  pcaRes <- reductionFunction(trainData)
  discriminant <- discriminantFunction(pcaRes$mat, trainClasses)

  testData <- projectionFunction(testData, pcaRes$eigvecs)
  results <- predictionFunction(discriminant, testData)
  
  truePos <- length(intersect(which(results$class == 1), which(testClasses == 1)))
  falsePos <- length(intersect(which(results$class == 1), which(testClasses != 1)))

  trueNeg <- length(intersect(which(results$class != 1), which(testClasses != 1)))
  falseNeg <- length(intersect(which(results$class != 1), which(testClasses == 1)))
  
  positivePredictiveValue <- truePos / (truePos + falsePos)
  percentageCorrectlyClassified <- (truePos + trueNeg) / (truePos + falsePos + trueNeg + falseNeg)
  sensitivity <- truePos / (truePos + falseNeg)
  specificity <- trueNeg / (falsePos + trueNeg)

  return(list(discriminant=discriminant,
              positivePredictiveValue=positivePredictiveValue,
              percentageCorrectlyClassified=percentageCorrectlyClassified,
              sensitivity=sensitivity, specificity=specificity))
}
