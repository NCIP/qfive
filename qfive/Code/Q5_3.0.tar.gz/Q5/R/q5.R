library(MASS)
library(caMassClass)
library(grDevices)

mzXML <- function(filename) {
  data <- NULL
  mz <- read.mzXML(filename)
  for (scan in mz$scan) {
    data$peaks <- rbind(data$peaks, scan$peaks)
    data$mass <- rbind(data$mass, scan$mass)
  }
  return(data)
}

normalize <- function(mat) {
  for (ixRow in seq(nrow(mat))) {
    rowMin <- min(mat[ixRow,])
    rowRange <- max(mat[ixRow,]) - rowMin
    mat[ixRow,] <- (mat[ixRow,] - rowMin) / rowRange
  }
  return(mat)
}

pca <- function(mat, eigenVectorsToRemove=4) {
  means <- rep(-1, ncol(mat))
  for (ix in seq(ncol(mat))) {
    means[ix] <- mean(mat[,ix])
    mat[,ix] <- mat[,ix] - means[ix]
  }
  res <- prcomp(mat)
  vals <- res$sdev**2
  vecs <- res$rotation
  x <- sort(vals, index.return=TRUE, decreasing=TRUE)
  vals <- vals[x$ix[1:(length(x$ix) - eigenVectorsToRemove)]]
  vecs <- vecs[,x$ix[1:(length(x$ix) - eigenVectorsToRemove)]]
  return(list(means=means, vecs=vecs, vals=vals))
}


pcaProject <- function(mat, means, vecs){
  # project into the pca space
  for (ix in seq(ncol(mat))) {
    mat[,ix] <- mat[,ix] - means[ix]
  }
  mat <- mat %*% vecs
  return(mat)
}

q5 <- function(trainData, trainClasses, testData, testClasses,
               reductionFunction=pca, eigenVectorsToRemove=4,
               discriminantFunction=lda,
               projectionFunction=pcaProject,
               predictionFunction=MASS:::predict.lda,
               statfile=NULL,
               plotfile=NULL) {
  # for trainClasses and testClasses, 1 indicates disease.
  pcaRes <- reductionFunction(trainData, eigenVectorsToRemove)
  trainData <- projectionFunction(trainData, pcaRes$means, pcaRes$vecs)
  discriminant <- discriminantFunction(trainData, trainClasses)

  testData <- projectionFunction(testData, pcaRes$means, pcaRes$vecs)
  results <- predictionFunction(discriminant, testData)
  
  truePos <- length(intersect(which(results$class == 1), which(testClasses == 1)))
  falsePos <- length(intersect(which(results$class == 1), which(testClasses != 1)))

  trueNeg <- length(intersect(which(results$class != 1), which(testClasses != 1)))
  falseNeg <- length(intersect(which(results$class != 1), which(testClasses == 1)))
  
  positivePredictiveValue <- truePos / (truePos + falsePos)
  percentageCorrectlyClassified <- (truePos + trueNeg) / (truePos + falsePos + trueNeg + falseNeg)
  sensitivity <- truePos / (truePos + falseNeg)
  specificity <- trueNeg / (falsePos + trueNeg)

  # write the statistics file
  sink(statfile)
  cat('positivePredictiveValue:\t')
  cat(positivePredictiveValue)
  cat('\n')
  cat('percentageCorrectlyClassified:\t')
  cat(percentageCorrectlyClassified)
  cat('\n')
  cat('percentageCorrectlyClassified:\t')
  cat(percentageCorrectlyClassified)
  cat('\n')
  cat('sensitivity:\t')
  cat(sensitivity)
  cat('\n')
  cat('specificity:\t')
  cat(specificity)
  cat('\n\n')
  sink()

  # plot the graph of the eigenvalues
  if (!is.null(plotfile)) {
    png(file=plotfile)
  }

  plot(pcaRes$vals)
  dev.off()

  return(list(discriminant=discriminant,
              positivePredictiveValue=positivePredictiveValue,
              percentageCorrectlyClassified=percentageCorrectlyClassified,
              sensitivity=sensitivity, specificity=specificity))
}

